% the fourth-order Runge Kutta method
function [Y,i] = RK4(f,t,Y0,Nt)
 N_var=numel(Y0); %Number of dependent variables
 h=(t(2)-t(1))/(Nt-1);%Calculate the step length
 Y=zeros(N_var,Nt);%the value during processing
 Y(:,1)=Y0(:);%initial value
 t=linspace(t(1),t(2),Nt);
 
 for i=1:Nt-1
     K1=f(Y(:,i),t(i));
     K2=f(Y(:,i)+K1*h/2,t(i)+h/2);
     K3=f(Y(:,i)+K2*h/2,t(i)+h/2);
     K4=f(Y(:,i)+K3*h,t(i)+h);
     Y(:,i+1)=Y(:,i)+h/6*(K1+2*K2+2*K3+K4);
     if max(abs(Y(:,i+1)-Y(:,i)))<10^(-6)
         return
     end
 end
end

