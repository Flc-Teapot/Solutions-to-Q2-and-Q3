E_0=1;
S_0=10;
ES_0=0;
P_0=0;
Y0=[E_0 S_0 ES_0 P_0]';%The initial value of the dependent variable
t=[0;10]% total time
Nt=1000000;%step number
f=@(Y,t)fun(Y,t,100,600,150)
[Y,i]=RK4(f,t,Y0,Nt);
Y=Y(:,1:i+2);
%plotting
V=zeros(1,i+1);

for j=1:i
    V(j)=(Y(4,j+1)-Y(4,j))/Y(4,j);
end
plot(Y(2,1:end-1),V);
xlabel('the concentrations of S (um)');
ylabel('the rate of change of the product P');
title('Q2-3');