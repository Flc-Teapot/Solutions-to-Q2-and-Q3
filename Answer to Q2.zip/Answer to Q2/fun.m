% This function is the equation set from 1 by using the law of mass action
function Y1=fun(Y,~,k1,k2,k3)
E=Y(1);
S=Y(2);
ES=Y(3);
P=Y(4);
Y1=zeros(4,1);
Y1(1)=-k1*E*S+k2*ES+k3*ES;
Y1(2)=-k1*E*S+k2*ES;
Y1(3)=k1*E*S-k2*ES-k3*ES;
Y1(4)=k3*ES;
end


